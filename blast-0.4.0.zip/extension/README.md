# 🔥 Blast — Error Debug Made Instant

> Select an error → Right-click → Get a fix. No Google, no ChatGPT, no config.

**Blast** is a VSCode extension that matches error messages against an offline knowledge base and gives you instant fixes. Built-in support for Python, JavaScript/TypeScript, Go, Rust, Java, Docker, and common system errors.

## Quick Start

1. Install from VSCode Marketplace (search "Blast") or download `.vsix` from [GitHub Releases](https://github.com/blast-debug/blast/releases)
2. Select error text in your editor → right-click → **"Blast: Analyze Selected Error"**
3. Fix appears in the sidebar — solutions, code fixes, and reference links

Or press `Ctrl+Alt+B` with error text selected.

## Features

- **🔍 Analyze Selected Error** — Select any error message, right-click, get fix (core flow)
- **▶ Run & Fix** — Run your `.py`/`.js`/`.ts`/`.go`/`.rb` file and catch errors automatically (`Ctrl+Alt+R`)
- **📋 Paste Error** — Command palette → paste error text → analyze
- **📚 Offline Knowledge Base** — 76 curated error patterns, zero API calls, <10ms matching
- **🌐 Multi-language UI** — English, 中文, 日本語, 한국어, Deutsch, Français, Español, Português
- **🔧 Code Fix Examples** — See "before vs after" code snippets
- **📖 Reference Links** — Direct links to official docs

## Supported Languages & Errors

| Language | Errors | Count |
|----------|--------|:-----:|
| Python | ModuleNotFound, ImportError, SyntaxError, IndentationError, TypeError, NameError, KeyError, IndexError, ValueError, FileNotFoundError, ZeroDivisionError, AttributeError, RecursionError, OSError, ConnectionError, TimeoutError, StopIteration, Unicode errors, f-string errors, circular imports, MemoryError, AssertionError, Flask 404/routing, Flask template, Django migration, coroutine not awaited, SQLAlchemy, NumPy shapes, Pandas KeyError | 30 |
| JavaScript/TypeScript | Cannot read property, not a function, SyntaxError (unexpected token), ReferenceError, Cannot set properties, JSON parse, Unhandled Promise, Network errors, already declared, RangeError (stack overflow), this context loss, Cannot find module, React hooks rules, useEffect dependency loop, TS type assignment | 15 |
| Docker | OOM killed (137), Port allocated, Exec format error, No space, Container restarting, COPY not found, DNS resolution, Volume permission | 8 |
| Go | Undefined name, Unused import, Nil pointer, Type mismatch, Concurrent map writes | 5 |
| Rust | Borrow after move, Missing mut, Incomplete match, Lifetime issues | 4 |
| Java | NullPointerException, ClassNotFound, ClassCastException, FileNotFound/IO | 4 |
| Common | Permission denied, Out of memory, Connection timeout, Git merge conflict, Command not found, Disk full, Address in use, SSL certificate, Env var not set, Matplotlib backend | 10 |

**Total: 76 error patterns**

Each entry includes:
- Precise regex patterns for matching
- 1-3 solution approaches with step-by-step instructions
- Code fix examples (wrong → correct)
- Reference documentation links

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+Alt+B` | Analyze selected error text |
| `Ctrl+Alt+R` | Run current file & analyze errors |

## Architecture

- **Pure TypeScript** — No Python runtime needed, embedded in VSCode
- **Zero external dependencies** — No API keys, no network calls
- **JSON knowledge base** — Patterns + solutions in structured JSON
- **Longest-match priority** — Specific patterns win over generic ones
- **Multi-language** — UI + knowledge base available in English and Chinese

## Development

```bash
# Install dependencies
npm install

# Compile TypeScript
npm run compile

# Run unit tests (28 tests)
node test.js

# Package .vsix
npx @vscode/vsce package
```

### Project Structure

```
blast-vscode/
├── src/
│   ├── extension.ts          # Plugin entry, commands
│   ├── knowledge/
│   │   ├── index.ts          # KB loader + match engine
│   │   └── data/
│   │       ├── python.json   (30 entries)
│   │       ├── javascript.json (15 entries)
│   │       ├── docker.json   (8 entries)
│   │       ├── golang.json   (5 entries)
│   │       ├── rust.json     (4 entries)
│   │       ├── java.json     (4 entries)
│   │       └── common.json   (10 entries)
│   ├── matcher/
│   │   └── engine.ts         # Regex matching engine
│   └── panels/
│       ├── sidebar.ts        # Sidebar WebView + i18n
│       └── result.ts         # Result panel
├── test.js                   # Unit tests
├── package.json
└── tsconfig.json
```

## Contributing

Knowledge base contributions are welcome! Each entry follows this format:

```json
{
  "id": "py-import-001",
  "title": "ModuleNotFoundError",
  "title_zh": "模块未找到 (ModuleNotFoundError)",
  "patterns": ["ModuleNotFoundError: No module named '(?P<module>[^']+)'"],
  "solutions": [
    {
      "type": "install",
      "title": "Install the missing package",
      "steps": ["pip install {module}", "Check virtual environment"]
    }
  ],
  "solutions_zh": [
    {
      "title": "安装缺失的包",
      "steps": ["pip install {module}", "检查虚拟环境"]
    }
  ],
  "code_fix": "# ❌ Error\n...\n\n# ✅ Fix\n...",
  "ref": "https://docs.python.org/..."
}
```

## License

MIT © 2026 Blast

## Roadmap

- [x] VSCode extension MVP
- [x] 76-entry knowledge base (6 languages + Docker + Common)
- [x] Multi-language UI (8 languages)
- [x] Code fix display
- [ ] `blast.exe` standalone CLI
- [ ] Community knowledge packs (`blast kb install`)
- [ ] AI fallback for unknown errors
- [ ] VSCode terminal output sniffing
